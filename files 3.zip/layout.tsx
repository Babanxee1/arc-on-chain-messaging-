import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Hausa USDC Hub API",
  description: "Circle Wallet SDK backend — Arc Testnet",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
