/**
 * app/page.tsx
 * Root page — shown when someone visits your Vercel URL directly.
 * Acts as a live API health check so you can confirm the deploy is working.
 */

const ROUTES = [
  { method: "POST", path: "/api/user",               desc: "Create user + get token + init wallet" },
  { method: "GET",  path: "/api/user",               desc: "Refresh session token" },
  { method: "GET",  path: "/api/wallet",             desc: "List wallets + balances" },
  { method: "GET",  path: "/api/balance",            desc: "Formatted USDC balance" },
  { method: "POST", path: "/api/transaction",        desc: "Create USDC transfer challenge" },
  { method: "GET",  path: "/api/transaction",        desc: "Transaction history" },
  { method: "GET",  path: "/api/status/[txId]",      desc: "Poll tx confirmation state" },
  { method: "POST", path: "/api/message",            desc: "Broadcast anonymous message" },
  { method: "GET",  path: "/api/message",            desc: "Fetch message history" },
  { method: "POST", path: "/api/relayer",            desc: "Provision relayer wallet (admin)" },
  { method: "GET",  path: "/api/relayer",            desc: "Relayer health + balance (admin)" },
];

const METHOD_COLORS: Record<string, string> = {
  GET:  "#1D9E75",
  POST: "#3B82F6",
};

export default function HomePage() {
  const configured = [
    ["CIRCLE_API_KEY",            !!process.env.CIRCLE_API_KEY],
    ["CIRCLE_ENTITY_SECRET",      !!process.env.CIRCLE_ENTITY_SECRET],
    ["NEXT_PUBLIC_CIRCLE_APP_ID", !!process.env.NEXT_PUBLIC_CIRCLE_APP_ID],
    ["ARC_USDC_TOKEN_ID",         !!process.env.ARC_USDC_TOKEN_ID],
    ["CIRCLE_RELAYER_WALLET_ID",  !!process.env.CIRCLE_RELAYER_WALLET_ID],
    ["MSG_CONTRACT_ADDRESS",      !!process.env.MSG_CONTRACT_ADDRESS],
    ["ADMIN_API_KEY",             !!process.env.ADMIN_API_KEY],
  ] as [string, boolean][];

  const allCritical = configured.slice(0, 3).every(([, v]) => v);

  return (
    <html>
      <head>
        <title>Hausa USDC Hub — API</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <style>{`
          * { box-sizing: border-box; margin: 0; padding: 0; }
          body { background: #080c10; color: #d4d4d8; font-family: 'IBM Plex Mono', monospace; padding: 2rem 1rem; }
          h1  { font-size: 1.1rem; color: #e4e4e7; margin-bottom: .25rem; }
          h2  { font-size: .7rem; color: #52525b; letter-spacing: .12em; text-transform: uppercase; margin: 1.5rem 0 .75rem; }
          .badge { display: inline-block; padding: .15rem .55rem; border-radius: 999px; font-size: .65rem; font-weight: 700; letter-spacing: .08em; }
          .ok  { background: #1D9E7520; color: #1D9E75; border: 1px solid #1D9E7540; }
          .err { background: #ef444420; color: #ef4444; border: 1px solid #ef444440; }
          .row { display: flex; align-items: center; gap: .75rem; padding: .55rem .75rem; border-radius: .5rem; border: 1px solid #27272a; margin-bottom: .4rem; }
          .method { font-size: .65rem; font-weight: 700; min-width: 2.8rem; }
          .path { font-size: .75rem; color: #a1a1aa; flex: 1; }
          .desc { font-size: .68rem; color: #52525b; }
          .env-row { display: flex; justify-content: space-between; align-items: center; padding: .4rem .75rem; border-radius: .4rem; border: 1px solid #1f2937; margin-bottom: .3rem; }
          .env-key { font-size: .7rem; color: #71717a; }
          .warn { background: #78350f20; border: 1px solid #78350f60; border-radius: .5rem; padding: .75rem 1rem; margin-top: 1rem; font-size: .72rem; color: #d97706; }
          .all-good { background: #1D9E7515; border: 1px solid #1D9E7540; border-radius: .5rem; padding: .75rem 1rem; margin-top: 1rem; font-size: .72rem; color: #1D9E75; }
          .dot { width: .45rem; height: .45rem; border-radius: 50%; display: inline-block; margin-right: .3rem; }
        `}</style>
      </head>
      <body>
        <h1>Hausa USDC Hub — API</h1>
        <span style={{ fontSize: '.65rem', color: '#3B82F6' }}>Arc Testnet · Next.js App Router</span>

        {allCritical
          ? <div className="all-good">✓ Critical env vars configured — API is operational</div>
          : <div className="warn">⚠ One or more critical env vars are missing. Add them in Vercel → Settings → Environment Variables, then redeploy.</div>
        }

        <h2>Environment variables</h2>
        {configured.map(([key, ok]) => (
          <div key={key} className="env-row">
            <span className="env-key">{key}</span>
            <span className={`badge ${ok ? "ok" : "err"}`}>{ok ? "SET" : "MISSING"}</span>
          </div>
        ))}

        <h2>API routes ({ROUTES.length})</h2>
        {ROUTES.map((r) => (
          <div key={r.method + r.path} className="row">
            <span className="method" style={{ color: METHOD_COLORS[r.method] }}>{r.method}</span>
            <span className="path">{r.path}</span>
            <span className="desc">{r.desc}</span>
          </div>
        ))}
      </body>
    </html>
  );
}
