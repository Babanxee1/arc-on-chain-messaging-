# Hausa USDC Hub — Backend API
# Next.js App Router · Circle Wallet SDK · Arc Mainnet

## Routes

| Method | Route | Auth | Description |
|--------|-------|------|-------------|
| POST | `/api/user` | — | Create user + get token + init wallet (3-in-1 onboarding) |
| GET | `/api/user?userId=` | — | Refresh userToken for existing user |
| GET | `/api/wallet` | X-User-Token | List wallets + balances for user |
| GET | `/api/balance?walletId=` | X-User-Token | Formatted USDC balance (home screen) |
| POST | `/api/transaction` | X-User-Token | Create USDC transfer challenge |
| GET | `/api/transaction?walletId=` | X-User-Token | Transaction history |
| GET | `/api/status/[txId]` | X-User-Token | Poll tx confirmation state |
| POST | `/api/message` | — | Broadcast anonymous on-chain message |
| GET | `/api/message?recipientAddress=` | — | Fetch message history |
| POST | `/api/relayer` | X-Admin-Key | Provision relayer wallet (run once) |
| GET | `/api/relayer` | X-Admin-Key | Relayer health + USDC balance |

---

## Quick setup

```bash
# 1. Install
npm install @circle-fin/user-controlled-wallets \
            @circle-fin/developer-controlled-wallets

# 2. Copy env template
cp .env.example .env.local

# 3. Generate entity secret (ONCE — save it securely)
npx ts-node -e "
  const { generateEntitySecret } = require('@circle-fin/developer-controlled-wallets');
  console.log(generateEntitySecret());
"

# 4. Register entity secret in Circle Developer Console
# → https://console.circle.com → Settings → Entity Secret

# 5. Run dev server
npm run dev

# 6. Provision relayer wallet (run once)
curl -X POST http://localhost:3000/api/relayer \
  -H "X-Admin-Key: your-admin-key"
# → Copy walletId → set CIRCLE_RELAYER_WALLET_ID

# 7. Fund relayer with USDC for gas fees
# → Send USDC to the relayer address on Arc Mainnet

# 8. Deploy messaging contract → set MSG_CONTRACT_ADDRESS
```

---

## Client-side flow

```typescript
// 1. Onboard user (call once on sign-up)
const { userToken, encryptionKey, challengeId } = await fetch('/api/user', {
  method: 'POST',
  body: JSON.stringify({ userId: 'your-app-user-id' })
}).then(r => r.json()).then(r => r.data)

// 2. Execute PIN setup challenge (opens Circle SDK UI)
sdk.setAppSettings({ appId: process.env.NEXT_PUBLIC_CIRCLE_APP_ID })
sdk.setAuthentication({ userToken, encryptionKey })
sdk.execute(challengeId, (err, result) => {
  // result.type === 'SET_PIN' → wallet now created
})

// 3. Load wallet
const { wallets } = await fetch('/api/wallet', {
  headers: { 'X-User-Token': userToken }
}).then(r => r.json()).then(r => r.data)

// 4. Send USDC
const { challengeId: sendChallenge } = await fetch('/api/transaction', {
  method: 'POST',
  headers: { 'X-User-Token': userToken },
  body: JSON.stringify({
    walletId: wallets[0].id,
    destinationAddress: '0x...',
    amount: '10.00',
    tokenId: wallets[0].balances[0].token.id
  })
}).then(r => r.json()).then(r => r.data)

// User approves in SDK UI
sdk.execute(sendChallenge, (err, result) => {
  // result.type === 'EXECUTE_TRANSACTION'
  // Poll /api/status/[txId] for confirmation
})
```

---

## Environment variables

See `.env.example` for the full list.

---

## Anonymous messaging architecture

```
User (client)
  │ encrypts message with recipient pubkey (ECIES)
  │ sends { encryptedPayload, recipientAddress, messageHash } to POST /api/message
  ▼
/api/message route (server — never sees plaintext)
  │ calls Circle developer-controlled wallet (relayer)
  │ relayer.createContractExecutionTransaction(MSG_CONTRACT_ADDRESS, payload)
  ▼
Arc Mainnet
  │ stores encrypted blob on-chain
  ▼
Recipient (client)
  │ fetches tx from GET /api/message
  │ decrypts with their private key
  ▼
Plaintext message (never left client, never touched server)
```
