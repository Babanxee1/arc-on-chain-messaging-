/**
 * lib/circle.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Shared Circle API client factory + typed helpers for Hausa USDC Hub.
 *
 * Both SDK clients are created as lazy singletons so they're only initialised
 * once per process (important for serverless cold-starts).
 *
 * Dependencies
 *   npm install @circle-fin/user-controlled-wallets
 *               @circle-fin/developer-controlled-wallets
 */

import {
  initiateUserControlledWalletsClient,
  type UserControlledWalletsClient,
} from "@circle-fin/user-controlled-wallets";

import {
  initiateDeveloperControlledWalletsClient,
  type DeveloperControlledWalletsClient,
} from "@circle-fin/developer-controlled-wallets";

// ─── Env validation ───────────────────────────────────────────────────────────

function requireEnv(key: string): string {
  const val = process.env[key];
  if (!val) throw new Error(`Missing required env var: ${key}`);
  return val;
}

// ─── Lazy singletons ──────────────────────────────────────────────────────────

let _userClient: UserControlledWalletsClient | null = null;
let _devClient: DeveloperControlledWalletsClient | null = null;

/**
 * Returns the user-controlled wallets SDK client.
 * Used for all user-scoped operations (create user, get token, send tx).
 */
export function getUserClient(): UserControlledWalletsClient {
  if (!_userClient) {
    _userClient = initiateUserControlledWalletsClient({
      apiKey: requireEnv("CIRCLE_API_KEY"),
    });
  }
  return _userClient;
}

/**
 * Returns the developer-controlled wallets SDK client.
 * Used for relayer wallet operations (anonymous message broadcasting).
 */
export function getDevClient(): DeveloperControlledWalletsClient {
  if (!_devClient) {
    _devClient = initiateDeveloperControlledWalletsClient({
      apiKey: requireEnv("CIRCLE_API_KEY"),
      entitySecret: requireEnv("CIRCLE_ENTITY_SECRET"),
    });
  }
  return _devClient;
}

// ─── Constants ────────────────────────────────────────────────────────────────

/** Arc Mainnet blockchain identifier used in Circle APIs */
export const ARC_MAINNET = "ARC-MAINNET" as const;

/** USDC token ID on Arc Mainnet — get from Circle Developer Console */
export const ARC_USDC_TOKEN_ID = requireEnvSafe("ARC_USDC_TOKEN_ID") ?? "REPLACE_WITH_TOKEN_ID";

/** Relayer wallet ID (developer-controlled) — used for anonymous messaging */
export const RELAYER_WALLET_ID = requireEnvSafe("CIRCLE_RELAYER_WALLET_ID") ?? "";

/** Messaging contract address on Arc */
export const MSG_CONTRACT_ADDRESS = requireEnvSafe("MSG_CONTRACT_ADDRESS") ?? "";

// ─── Typed API response wrapper ───────────────────────────────────────────────

export interface ApiSuccess<T> {
  ok: true;
  data: T;
}

export interface ApiError {
  ok: false;
  error: string;
  code?: number;
}

export type ApiResponse<T> = ApiSuccess<T> | ApiError;

export function success<T>(data: T): ApiSuccess<T> {
  return { ok: true, data };
}

export function failure(error: string, code?: number): ApiError {
  return { ok: false, error, code };
}

// ─── Error normaliser ─────────────────────────────────────────────────────────

export function normaliseError(e: unknown): string {
  if (e instanceof Error) return e.message;
  if (typeof e === "object" && e !== null && "message" in e) {
    return String((e as { message: unknown }).message);
  }
  return "An unexpected error occurred";
}

// ─── Idempotency key generator ────────────────────────────────────────────────

export function idempotencyKey(prefix = "hausa"): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

// Helper that won't throw at module load time
function requireEnvSafe(key: string): string | undefined {
  return process.env[key];
}
