/**
 * app/api/user/route.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * POST /api/user
 *
 * Consolidates three Circle API calls into a single onboarding endpoint:
 *   1. POST /v1/w3s/users          → create user record
 *   2. POST /v1/w3s/users/token    → get userToken + encryptionKey (60-min TTL)
 *   3. POST /v1/w3s/user/initialize → get challengeId for SET_PIN flow
 *
 * The frontend receives { userToken, encryptionKey, challengeId } and passes
 * them straight to W3SSdk.execute(challengeId) to open the PIN setup UI.
 *
 * Body:
 *   { userId: string }   — your app's unique ID for this user (UUID recommended)
 *
 * Response 200:
 *   {
 *     ok: true,
 *     data: {
 *       userId: string,
 *       userToken: string,        // pass to W3SSdk.setAuthentication()
 *       encryptionKey: string,    // pass to W3SSdk.setAuthentication()
 *       challengeId: string,      // pass to W3SSdk.execute()
 *       isNewUser: boolean,
 *     }
 *   }
 */

import { NextRequest, NextResponse } from "next/server";
import { getUserClient, success, failure, normaliseError, ARC_MAINNET } from "@/lib/circle";

// userAlreadyExisted error code from Circle SDK
const USER_ALREADY_EXISTS_CODE = 155101;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { userId } = body as { userId?: string };

    if (!userId || typeof userId !== "string" || userId.trim().length === 0) {
      return NextResponse.json(failure("userId is required"), { status: 400 });
    }

    const client = getUserClient();
    let isNewUser = true;

    // ── Step 1: Create user ───────────────────────────────────────────────────
    // Idempotent: if user already exists, Circle returns error code 155101.
    // We catch it and continue — this makes the route safe to call on every login.
    try {
      await client.createUser({ userId });
    } catch (e: unknown) {
      const code = extractCircleErrorCode(e);
      if (code === USER_ALREADY_EXISTS_CODE) {
        isNewUser = false;
        // Not a real error — user exists from a previous session
      } else {
        throw e; // Rethrow unexpected errors
      }
    }

    // ── Step 2: Get session token (60-minute TTL) ─────────────────────────────
    const tokenRes = await client.createUserToken({ userId });
    const userToken = tokenRes.data?.userToken;
    const encryptionKey = tokenRes.data?.encryptionKey;

    if (!userToken || !encryptionKey) {
      return NextResponse.json(
        failure("Failed to obtain user token from Circle"),
        { status: 502 }
      );
    }

    // ── Step 3: Initialize user / get wallet challenge ────────────────────────
    // For a new user → returns challengeId for SET_PIN + CREATE_WALLET
    // For an existing initialized user → returns existing wallet data (no challengeId)
    const initRes = await client.createUserPinWithWallets({
      userToken,
      accountType: "SCA",           // Smart Contract Account: supports gasless txs
      blockchains: [ARC_MAINNET],
    });

    const challengeId = initRes.data?.challengeId;

    return NextResponse.json(
      success({
        userId,
        userToken,
        encryptionKey,
        challengeId: challengeId ?? null,
        isNewUser,
        // If null: user is already initialized — skip PIN challenge, go to wallet
        requiresSetup: !!challengeId,
      })
    );
  } catch (e) {
    console.error("[POST /api/user]", e);
    return NextResponse.json(failure(normaliseError(e)), { status: 500 });
  }
}

// ─── GET /api/user?userId=xxx — fetch user info ───────────────────────────────
export async function GET(req: NextRequest) {
  try {
    const userId = req.nextUrl.searchParams.get("userId");
    if (!userId) {
      return NextResponse.json(failure("userId query param required"), { status: 400 });
    }

    const client = getUserClient();
    const tokenRes = await client.createUserToken({ userId });
    const userToken = tokenRes.data?.userToken;
    const encryptionKey = tokenRes.data?.encryptionKey;

    if (!userToken || !encryptionKey) {
      return NextResponse.json(failure("Failed to get user token"), { status: 502 });
    }

    return NextResponse.json(success({ userId, userToken, encryptionKey }));
  } catch (e) {
    console.error("[GET /api/user]", e);
    return NextResponse.json(failure(normaliseError(e)), { status: 500 });
  }
}

// ─── Helper: extract Circle error code ───────────────────────────────────────
function extractCircleErrorCode(e: unknown): number | null {
  if (typeof e === "object" && e !== null) {
    const err = e as Record<string, unknown>;
    // Circle SDK wraps errors in response.data.code
    if ("response" in err) {
      const resp = err.response as Record<string, unknown>;
      if ("data" in resp) {
        const data = resp.data as Record<string, unknown>;
        if (typeof data.code === "number") return data.code;
      }
    }
    if (typeof err.code === "number") return err.code;
  }
  return null;
}
