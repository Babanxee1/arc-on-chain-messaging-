/**
 * middleware.ts  (Next.js root middleware — runs on every /api/* request)
 * ─────────────────────────────────────────────────────────────────────────────
 * Handles:
 *   • CORS headers (allow your frontend origin)
 *   • Rate limiting (simple in-memory token bucket — swap for Upstash Redis in prod)
 *   • Request logging (structured JSON logs)
 *   • Security headers
 *
 * In production replace the in-memory rate limiter with:
 *   npm install @upstash/ratelimit @upstash/redis
 */

import { NextRequest, NextResponse } from "next/server";

// ─── Config ───────────────────────────────────────────────────────────────────
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS ?? "http://localhost:3000").split(",");
const RATE_LIMIT_WINDOW_MS = 60_000;     // 1 minute
const RATE_LIMIT_MAX_REQUESTS = 60;      // 60 req/min per IP (generous for mobile)

// ─── In-memory rate limiter ───────────────────────────────────────────────────
// ⚠ This resets on each cold start — use Upstash Redis for multi-instance prod.
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(ip: string): { allowed: boolean; remaining: number; resetAt: number } {
  const now = Date.now();
  const entry = rateLimitMap.get(ip);

  if (!entry || now > entry.resetAt) {
    const resetAt = now + RATE_LIMIT_WINDOW_MS;
    rateLimitMap.set(ip, { count: 1, resetAt });
    return { allowed: true, remaining: RATE_LIMIT_MAX_REQUESTS - 1, resetAt };
  }

  if (entry.count >= RATE_LIMIT_MAX_REQUESTS) {
    return { allowed: false, remaining: 0, resetAt: entry.resetAt };
  }

  entry.count++;
  return {
    allowed: true,
    remaining: RATE_LIMIT_MAX_REQUESTS - entry.count,
    resetAt: entry.resetAt,
  };
}

// ─── Middleware ───────────────────────────────────────────────────────────────
export function middleware(req: NextRequest) {
  const { pathname, origin } = req.nextUrl;
  const method = req.method;
  const reqOrigin = req.headers.get("origin") ?? "";
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "unknown";
  const start = Date.now();

  // ── Handle CORS preflight ─────────────────────────────────────────────────
  if (method === "OPTIONS") {
    return new NextResponse(null, {
      status: 204,
      headers: corsHeaders(reqOrigin),
    });
  }

  // ── Rate limit ────────────────────────────────────────────────────────────
  const rl = checkRateLimit(ip);
  if (!rl.allowed) {
    const retryAfterSec = Math.ceil((rl.resetAt - Date.now()) / 1000);
    return NextResponse.json(
      { ok: false, error: "Too many requests. Slow down a bit." },
      {
        status: 429,
        headers: {
          ...corsHeaders(reqOrigin),
          "Retry-After": String(retryAfterSec),
          "X-RateLimit-Remaining": "0",
          "X-RateLimit-Reset": String(rl.resetAt),
        },
      }
    );
  }

  // ── Continue to route handler ─────────────────────────────────────────────
  const res = NextResponse.next();

  // Apply CORS + security headers
  const headers = {
    ...corsHeaders(reqOrigin),
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-RateLimit-Remaining": String(rl.remaining),
    "X-RateLimit-Reset": String(rl.resetAt),
  };

  Object.entries(headers).forEach(([k, v]) => res.headers.set(k, v));

  // Structured request log (pipe to Datadog / Logtail / etc.)
  console.log(
    JSON.stringify({
      ts: new Date().toISOString(),
      method,
      path: pathname,
      ip,
      origin: reqOrigin,
      ms: Date.now() - start,
    })
  );

  return res;
}

export const config = {
  matcher: "/api/:path*",
};

// ─── CORS helper ──────────────────────────────────────────────────────────────
function corsHeaders(reqOrigin: string): Record<string, string> {
  const allowed = ALLOWED_ORIGINS.includes(reqOrigin) ? reqOrigin : ALLOWED_ORIGINS[0];
  return {
    "Access-Control-Allow-Origin": allowed,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, X-User-Token, X-Admin-Key",
    "Access-Control-Max-Age": "86400",
  };
}
