/**
 * app/api/message/route.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * POST /api/message  — broadcast an anonymous on-chain message via relayer
 * GET  /api/message  — fetch message history from contract events
 *
 * ── Architecture ─────────────────────────────────────────────────────────────
 * Anonymous messaging uses a DEVELOPER-CONTROLLED relayer wallet (not the
 * user's wallet) so the sender's identity is never linked to the message tx.
 *
 * Flow:
 *   1. Client sends { recipientAddress, messageHash, encryptedPayload }
 *   2. Server calls createContractExecutionTransaction on the relayer wallet
 *   3. Circle broadcasts the tx — recipient address + encrypted blob stored on-chain
 *   4. Recipient decrypts with their private key client-side
 *
 * The message content is NEVER stored on the server — only the encrypted
 * payload that only the recipient can decrypt.
 *
 * Body:
 *   {
 *     recipientAddress: string,    // 0x address of recipient
 *     encryptedPayload: string,    // ECIES-encrypted message (client-side encrypted)
 *     messageHash: string,         // keccak256 of plaintext for integrity check
 *     senderAnonId: string,        // ephemeral anon handle (no real identity)
 *   }
 *
 * Response 200:
 *   { ok: true, data: { txId: string, txHash: null } }
 *   → Poll GET /api/status/[txId] for confirmation
 *
 * ── GET: Fetch messages ───────────────────────────────────────────────────────
 * Params: recipientAddress, pageSize, pageAfter
 *
 * In production this would index contract events. Here we query Circle's
 * transaction history for the messaging contract filtered by recipient.
 */

import { NextRequest, NextResponse } from "next/server";
import {
  getDevClient,
  success,
  failure,
  normaliseError,
  idempotencyKey,
  RELAYER_WALLET_ID,
  MSG_CONTRACT_ADDRESS,
} from "@/lib/circle";

// ABI function signature for the messaging contract
// sendMessage(address recipient, bytes encryptedPayload, bytes32 messageHash)
const SEND_MESSAGE_SIG = "sendMessage(address,bytes,bytes32)";

// ── POST: Send anonymous message ──────────────────────────────────────────────
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { recipientAddress, encryptedPayload, messageHash, senderAnonId } = body as {
      recipientAddress?: string;
      encryptedPayload?: string;
      messageHash?: string;
      senderAnonId?: string;
    };

    // ── Validation ────────────────────────────────────────────────────────────
    if (!recipientAddress || !encryptedPayload || !messageHash) {
      return NextResponse.json(
        failure("recipientAddress, encryptedPayload, and messageHash are required"),
        { status: 400 }
      );
    }

    if (!/^0x[0-9a-fA-F]{40}$/.test(recipientAddress)) {
      return NextResponse.json(
        failure("recipientAddress must be a valid 0x address"),
        { status: 400 }
      );
    }

    if (encryptedPayload.length > 10_000) {
      return NextResponse.json(
        failure("Encrypted payload too large (max 10KB)"),
        { status: 413 }
      );
    }

    if (!RELAYER_WALLET_ID) {
      return NextResponse.json(
        failure("Relayer wallet not configured. Set CIRCLE_RELAYER_WALLET_ID env var."),
        { status: 503 }
      );
    }

    if (!MSG_CONTRACT_ADDRESS) {
      return NextResponse.json(
        failure("Messaging contract not configured. Set MSG_CONTRACT_ADDRESS env var."),
        { status: 503 }
      );
    }

    const client = getDevClient();

    // ── Broadcast via relayer wallet ──────────────────────────────────────────
    // The developer-controlled wallet signs and sends — user identity never touched.
    // On Arc, USDC covers gas so relayer doesn't need native tokens.
    const txRes = await client.createContractExecutionTransaction({
      walletId: RELAYER_WALLET_ID,
      contractAddress: MSG_CONTRACT_ADDRESS,
      abiFunctionSignature: SEND_MESSAGE_SIG,
      abiParameters: [
        recipientAddress,
        encryptedPayload,      // bytes — hex or base64 depending on your contract
        messageHash,           // bytes32
      ],
      idempotencyKey: idempotencyKey("msg"),
      fee: {
        type: "EIP1559",
        config: { maxFee: "0.001", priorityFee: "0.0001" },
      },
    });

    const txId = txRes.data?.id;
    if (!txId) {
      return NextResponse.json(
        failure("Relayer transaction failed to initiate"),
        { status: 502 }
      );
    }

    // Log anonymously — no user identity stored
    console.log(`[MSG RELAY] txId=${txId} anonId=${senderAnonId ?? "unknown"}`);

    return NextResponse.json(
      success({
        txId,
        txHash: null, // Not available yet — poll /api/status/[txId]
        statusUrl: `/api/status/${txId}`,
        note: "Message encrypted and relayed. Poll statusUrl for confirmation.",
      })
    );
  } catch (e) {
    console.error("[POST /api/message]", e);
    return NextResponse.json(failure(normaliseError(e)), { status: 500 });
  }
}

// ── GET: Fetch message history ────────────────────────────────────────────────
// Queries Circle's transaction list for the messaging contract address.
// In a production system you'd index contract events into your own DB.
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = req.nextUrl;
    const recipientAddress = searchParams.get("recipientAddress");

    if (!recipientAddress) {
      return NextResponse.json(
        failure("recipientAddress query param required"),
        { status: 400 }
      );
    }

    if (!MSG_CONTRACT_ADDRESS) {
      return NextResponse.json(success({ messages: [] }));
    }

    const client = getDevClient();

    // Fetch transactions from the relayer wallet to/from the contract
    const txRes = await client.listTransactions({
      walletIds: [RELAYER_WALLET_ID],
      destinationAddress: MSG_CONTRACT_ADDRESS,
      pageSize: 50,
    });

    const allTxs = txRes.data?.transactions ?? [];

    // Filter to only txs involving this recipient (check abiParameters if indexed)
    // In production: replace with event indexing (e.g., The Graph or your own DB)
    const messages = allTxs.map((tx) => ({
      txId: tx.id,
      txHash: tx.txHash,
      state: tx.state,
      timestamp: tx.createDate,
      // encryptedPayload would come from contract event logs, not the tx record
    }));

    return NextResponse.json(success({ messages, count: messages.length }));
  } catch (e) {
    console.error("[GET /api/message]", e);
    return NextResponse.json(failure(normaliseError(e)), { status: 500 });
  }
}
