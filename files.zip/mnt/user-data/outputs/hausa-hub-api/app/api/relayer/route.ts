/**
 * app/api/relayer/route.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * POST /api/relayer/setup  — one-time admin route to provision the relayer wallet
 * GET  /api/relayer/status — check relayer wallet balance + health
 *
 * ── Overview ──────────────────────────────────────────────────────────────────
 * The relayer is a developer-controlled SCA wallet on Arc that:
 *   • Signs and broadcasts all anonymous messages (so sender ≠ relayer)
 *   • Pays gas in USDC (Arc native gas)
 *   • Never holds user funds — only enough USDC for gas fees
 *
 * Run POST /api/relayer/setup ONCE during infrastructure setup.
 * Save the returned walletId to CIRCLE_RELAYER_WALLET_ID env var.
 *
 * ── Security ──────────────────────────────────────────────────────────────────
 * Both routes are protected by ADMIN_API_KEY. Never expose this endpoint
 * publicly — add it behind an internal network or admin auth middleware.
 */

import { NextRequest, NextResponse } from "next/server";
import {
  getDevClient,
  success,
  failure,
  normaliseError,
  ARC_MAINNET,
  RELAYER_WALLET_ID,
} from "@/lib/circle";

// ── Admin auth middleware ──────────────────────────────────────────────────────
function isAuthorized(req: NextRequest): boolean {
  const key = req.headers.get("x-admin-key");
  return key === process.env.ADMIN_API_KEY && !!process.env.ADMIN_API_KEY;
}

// ── POST /api/relayer — provision relayer ─────────────────────────────────────
export async function POST(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json(failure("Unauthorized"), { status: 401 });
  }

  try {
    const client = getDevClient();

    // Step 1: Create a WalletSet for the Hausa Hub relayer
    const walletSetRes = await client.createWalletSet({
      name: "HausaHub-RelayerSet",
    });

    const walletSetId = walletSetRes.data?.walletSet?.id;
    if (!walletSetId) {
      return NextResponse.json(failure("Failed to create WalletSet"), { status: 502 });
    }

    // Step 2: Create SCA wallet on Arc
    // SCA = Smart Contract Account: supports EIP-4337 (account abstraction)
    // which enables gasless/sponsored transactions and batching
    const walletsRes = await client.createWallets({
      walletSetId,
      blockchains: [ARC_MAINNET],
      accountType: "SCA",
      count: 1,
      metadata: [{ name: "HausaHub Relayer", refId: "hausa-hub-relayer-v1" }],
    });

    const wallet = walletsRes.data?.wallets?.[0];
    if (!wallet) {
      return NextResponse.json(failure("Failed to create relayer wallet"), { status: 502 });
    }

    return NextResponse.json(
      success({
        walletSetId,
        walletId: wallet.id,
        address: wallet.address,
        blockchain: wallet.blockchain,
        accountType: wallet.accountType,
        state: wallet.state,
        instructions: [
          `1. Save walletId to env: CIRCLE_RELAYER_WALLET_ID=${wallet.id}`,
          `2. Fund this address with USDC for gas: ${wallet.address}`,
          `3. Deploy your messaging contract and set MSG_CONTRACT_ADDRESS`,
          `4. Restart the server — relayer is ready`,
        ],
      })
    );
  } catch (e) {
    console.error("[POST /api/relayer]", e);
    return NextResponse.json(failure(normaliseError(e)), { status: 500 });
  }
}

// ── GET /api/relayer — check relayer health + balance ─────────────────────────
export async function GET(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json(failure("Unauthorized"), { status: 401 });
  }

  try {
    if (!RELAYER_WALLET_ID) {
      return NextResponse.json(
        success({
          status: "NOT_CONFIGURED",
          message: "CIRCLE_RELAYER_WALLET_ID not set. Run POST /api/relayer first.",
        })
      );
    }

    const client = getDevClient();

    const walletRes = await client.getWallet({ id: RELAYER_WALLET_ID });
    const wallet = walletRes.data?.wallet;

    const balRes = await client.getWalletTokenBalance({ id: RELAYER_WALLET_ID });
    const balances = balRes.data?.tokenBalances ?? [];

    const usdcBalance = balances.find((b) =>
      b.token?.symbol?.toUpperCase().includes("USDC")
    );

    const usdcAmount = Number(usdcBalance?.amount ?? 0);
    const lowBalanceWarning = usdcAmount < 1; // warn if less than $1 USDC for gas

    return NextResponse.json(
      success({
        status: wallet?.state ?? "UNKNOWN",
        walletId: RELAYER_WALLET_ID,
        address: wallet?.address,
        blockchain: wallet?.blockchain,
        balances,
        usdcBalance: usdcBalance?.amount ?? "0",
        health: lowBalanceWarning ? "LOW_BALANCE" : "OK",
        warning: lowBalanceWarning
          ? `Relayer USDC balance is low ($${usdcAmount.toFixed(2)}). Refund to continue relaying.`
          : null,
      })
    );
  } catch (e) {
    console.error("[GET /api/relayer]", e);
    return NextResponse.json(failure(normaliseError(e)), { status: 500 });
  }
}
