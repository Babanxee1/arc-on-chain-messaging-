/**
 * app/api/status/[txId]/route.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * GET /api/status/[txId]
 *
 * Poll the on-chain confirmation state of a transaction.
 * Used by the Tx Status feed in the dashboard to show live confirmation progress.
 *
 * Headers:  X-User-Token: <userToken>
 *
 * Response 200:
 *   {
 *     ok: true,
 *     data: {
 *       id: string,
 *       state: "INITIATED" | "PENDING_RISK_SCREENING" | "SENT" | "CONFIRMED" | "FAILED" | "CANCELLED",
 *       txHash: string | null,
 *       blockchain: string,
 *       amounts: string[],
 *       networkFee: string | null,
 *       createDate: string,
 *       updateDate: string,
 *       // Derived helpers for the UI:
 *       isTerminal: boolean,    // true when state won't change anymore
 *       isFailed: boolean,
 *       isConfirmed: boolean,
 *     }
 *   }
 */

import { NextRequest, NextResponse } from "next/server";
import { getUserClient, success, failure, normaliseError } from "@/lib/circle";

// States that will never change again
const TERMINAL_STATES = new Set(["CONFIRMED", "FAILED", "CANCELLED", "COMPLETE"]);

export async function GET(
  req: NextRequest,
  { params }: { params: { txId: string } }
) {
  try {
    const { txId } = params;

    if (!txId || txId.trim().length === 0) {
      return NextResponse.json(failure("txId is required"), { status: 400 });
    }

    const userToken = req.headers.get("x-user-token");
    if (!userToken) {
      return NextResponse.json(failure("X-User-Token header is required"), { status: 401 });
    }

    const client = getUserClient();

    const txRes = await client.getTransaction({ id: txId, userToken });
    const tx = txRes.data?.transaction;

    if (!tx) {
      return NextResponse.json(failure("Transaction not found"), { status: 404 });
    }

    const state = String(tx.state ?? "UNKNOWN");
    const isTerminal = TERMINAL_STATES.has(state);

    return NextResponse.json(
      success({
        id: tx.id,
        state,
        txHash: tx.txHash ?? null,
        blockchain: tx.blockchain,
        amounts: tx.amounts ?? [],
        destinationAddress: tx.destinationAddress ?? null,
        sourceAddress: tx.sourceAddress ?? null,
        networkFee: tx.networkFee ?? null,
        createDate: tx.createDate,
        updateDate: tx.updateDate,
        // Derived flags for the frontend status badge
        isTerminal,
        isFailed: state === "FAILED" || state === "CANCELLED",
        isConfirmed: state === "CONFIRMED" || state === "COMPLETE",
        // Suggested polling interval (ms) — slow down once confirmed
        nextPollMs: isTerminal ? null : state === "SENT" ? 3000 : 5000,
      }),
      {
        // Short cache for in-flight txs, no cache once terminal
        headers: {
          "Cache-Control": isTerminal
            ? "public, max-age=300"
            : "no-store",
        },
      }
    );
  } catch (e) {
    console.error("[GET /api/status/:txId]", e);
    return NextResponse.json(failure(normaliseError(e)), { status: 500 });
  }
}
