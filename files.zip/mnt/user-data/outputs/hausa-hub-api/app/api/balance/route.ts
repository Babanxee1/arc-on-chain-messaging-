/**
 * app/api/balance/route.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * GET /api/balance
 *
 * Returns formatted USDC balance for a specific wallet.
 * Lightweight alternative to GET /api/wallet when you only need the balance.
 * Used by the home screen balance display + send-flow amount validation.
 *
 * Headers:  X-User-Token: <userToken>
 * Params:   walletId (required)
 *
 * Response 200:
 *   {
 *     ok: true,
 *     data: {
 *       walletId: string,
 *       address: string,
 *       usdc: {
 *         raw: string,          // "10500000"   (6 decimal places)
 *         formatted: string,    // "10.50"
 *         display: string,      // "10.50 USDC"
 *         hausa: string,        // "USDC 10.50" (Hausa display order)
 *       },
 *       allBalances: Array<{ symbol, name, amount, tokenId }>,
 *       lastUpdated: string,    // ISO timestamp
 *     }
 *   }
 */

import { NextRequest, NextResponse } from "next/server";
import { getUserClient, success, failure, normaliseError } from "@/lib/circle";

export async function GET(req: NextRequest) {
  try {
    const userToken = req.headers.get("x-user-token");
    if (!userToken) {
      return NextResponse.json(failure("X-User-Token header is required"), { status: 401 });
    }

    const walletId = req.nextUrl.searchParams.get("walletId");
    if (!walletId) {
      return NextResponse.json(failure("walletId query param required"), { status: 400 });
    }

    const client = getUserClient();

    // Fetch wallet info + balances in parallel
    const [walletRes, balRes] = await Promise.all([
      client.getWallet({ id: walletId, userToken }),
      client.getWalletTokenBalance({ id: walletId, userToken }),
    ]);

    const wallet = walletRes.data?.wallet;
    const balances = balRes.data?.tokenBalances ?? [];

    if (!wallet) {
      return NextResponse.json(failure("Wallet not found"), { status: 404 });
    }

    // Find USDC balance (works for native USDC on Arc or ERC-20 on other chains)
    const usdcBalance = balances.find(
      (b) =>
        b.token?.symbol?.toUpperCase() === "USDC" ||
        b.token?.name?.toUpperCase().includes("USD COIN")
    );

    const rawAmount = usdcBalance?.amount ?? "0";
    const formattedAmount = formatUsdc(rawAmount);

    // Shape all balances for the UI
    const allBalances = balances.map((b) => ({
      symbol: b.token?.symbol ?? "UNKNOWN",
      name: b.token?.name ?? "Unknown Token",
      amount: b.amount ?? "0",
      tokenId: b.token?.id,
      formatted: formatTokenAmount(b.amount ?? "0", b.token?.decimals ?? 18),
    }));

    return NextResponse.json(
      success({
        walletId,
        address: wallet.address,
        blockchain: wallet.blockchain,
        usdc: {
          raw: rawAmount,
          formatted: formattedAmount,
          display: `${formattedAmount} USDC`,
          hausa: `USDC ${formattedAmount}`,       // Hausa language display convention
          tokenId: usdcBalance?.token?.id ?? null,
        },
        allBalances,
        lastUpdated: new Date().toISOString(),
      }),
      {
        // Balance can be cached briefly — 10s is enough to prevent hammering
        headers: { "Cache-Control": "public, max-age=10, stale-while-revalidate=30" },
      }
    );
  } catch (e) {
    console.error("[GET /api/balance]", e);
    return NextResponse.json(failure(normaliseError(e)), { status: 500 });
  }
}

// ─── Formatters ───────────────────────────────────────────────────────────────

/**
 * USDC uses 6 decimal places.
 * "10500000" → "10.50"
 * "1000000"  → "1.00"
 */
function formatUsdc(raw: string): string {
  const n = Number(raw);
  if (isNaN(n)) return "0.00";
  // If the value looks like it's already in human-readable form (< 1000 and has decimal)
  if (raw.includes(".") || n < 1_000_000) {
    return n.toFixed(2);
  }
  return (n / 1_000_000).toFixed(2);
}

function formatTokenAmount(raw: string, decimals: number): string {
  const n = Number(raw);
  if (isNaN(n)) return "0";
  if (raw.includes(".")) return parseFloat(raw).toFixed(4);
  const divisor = Math.pow(10, decimals);
  return (n / divisor).toFixed(decimals > 6 ? 4 : 2);
}
