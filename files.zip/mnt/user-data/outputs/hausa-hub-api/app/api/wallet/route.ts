/**
 * app/api/wallet/route.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * GET /api/wallet?userId=xxx
 *
 * Returns the user's Arc wallet address + USDC balance.
 * Called after the SET_PIN challenge completes to load the home screen.
 *
 * This route requires a fresh userToken — the client should call
 * GET /api/user?userId=xxx first to get one, then include it as a header.
 *
 * Headers:
 *   X-User-Token: <userToken>   — required for user-scoped wallet lookup
 *
 * Response 200:
 *   {
 *     ok: true,
 *     data: {
 *       wallets: Array<{
 *         id: string,
 *         address: string,
 *         blockchain: string,
 *         accountType: "SCA" | "EOA",
 *         state: string,
 *         balances: Array<{ token: { symbol, name }, amount }>,
 *         custodyType: string,
 *       }>
 *     }
 *   }
 */

import { NextRequest, NextResponse } from "next/server";
import { getUserClient, success, failure, normaliseError } from "@/lib/circle";

export async function GET(req: NextRequest) {
  try {
    const userToken = req.headers.get("x-user-token");
    if (!userToken) {
      return NextResponse.json(
        failure("X-User-Token header is required"),
        { status: 401 }
      );
    }

    const client = getUserClient();

    // Fetch all wallets for this user session
    const walletsRes = await client.listWallets({ userToken });
    const wallets = walletsRes.data?.wallets ?? [];

    if (wallets.length === 0) {
      return NextResponse.json(
        success({ wallets: [], message: "No wallets found. Complete PIN setup first." })
      );
    }

    // Fetch balances for each wallet in parallel
    const walletsWithBalances = await Promise.all(
      wallets.map(async (wallet) => {
        try {
          const balRes = await client.getWalletTokenBalance({
            id: wallet.id,
            userToken,
          });
          return {
            id: wallet.id,
            address: wallet.address,
            blockchain: wallet.blockchain,
            accountType: wallet.accountType,
            state: wallet.state,
            custodyType: wallet.custodyType,
            balances: balRes.data?.tokenBalances ?? [],
          };
        } catch {
          // Return wallet without balance rather than failing the whole request
          return {
            id: wallet.id,
            address: wallet.address,
            blockchain: wallet.blockchain,
            accountType: wallet.accountType,
            state: wallet.state,
            custodyType: wallet.custodyType,
            balances: [],
          };
        }
      })
    );

    return NextResponse.json(success({ wallets: walletsWithBalances }));
  } catch (e) {
    console.error("[GET /api/wallet]", e);
    return NextResponse.json(failure(normaliseError(e)), { status: 500 });
  }
}
