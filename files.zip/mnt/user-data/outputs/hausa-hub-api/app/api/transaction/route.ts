/**
 * app/api/transaction/route.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * POST /api/transaction  — create a USDC transfer challenge
 * GET  /api/transaction  — list transaction history for a user wallet
 *
 * ── POST ─────────────────────────────────────────────────────────────────────
 * Creates a transfer challenge on Circle's backend. The client then calls
 * W3SSdk.execute(challengeId) — which prompts the user for their PIN before
 * the transaction is signed and broadcast.
 *
 * Headers:  X-User-Token: <userToken>
 *
 * Body:
 *   {
 *     walletId: string,           // source wallet (from GET /api/wallet)
 *     destinationAddress: string, // recipient 0x address
 *     amount: string,             // e.g. "10.50"  (human-readable USDC, 6 decimals)
 *     tokenId: string,            // USDC token ID on Arc (from env or wallet balances)
 *   }
 *
 * Response 200:
 *   { ok: true, data: { challengeId: string } }
 *   → pass challengeId to W3SSdk.execute() on the client
 *
 * ── GET ──────────────────────────────────────────────────────────────────────
 * Headers:  X-User-Token: <userToken>
 * Params:   walletId, pageSize (optional, default 20), pageAfter (optional cursor)
 *
 * Response 200:
 *   { ok: true, data: { transactions: [...], nextPageAfter?: string } }
 */

import { NextRequest, NextResponse } from "next/server";
import {
  getUserClient,
  success,
  failure,
  normaliseError,
  idempotencyKey,
} from "@/lib/circle";

// ── POST: Create transfer challenge ───────────────────────────────────────────
export async function POST(req: NextRequest) {
  try {
    const userToken = req.headers.get("x-user-token");
    if (!userToken) {
      return NextResponse.json(failure("X-User-Token header is required"), { status: 401 });
    }

    const body = await req.json();
    const { walletId, destinationAddress, amount, tokenId } = body as {
      walletId?: string;
      destinationAddress?: string;
      amount?: string;
      tokenId?: string;
    };

    // ── Input validation ──────────────────────────────────────────────────────
    const missing = (
      [
        ["walletId", walletId],
        ["destinationAddress", destinationAddress],
        ["amount", amount],
        ["tokenId", tokenId],
      ] as [string, string | undefined][]
    )
      .filter(([, v]) => !v)
      .map(([k]) => k);

    if (missing.length > 0) {
      return NextResponse.json(
        failure(`Missing required fields: ${missing.join(", ")}`),
        { status: 400 }
      );
    }

    if (!isValidAddress(destinationAddress!)) {
      return NextResponse.json(
        failure("destinationAddress must be a valid 0x Ethereum address"),
        { status: 400 }
      );
    }

    if (!isPositiveAmount(amount!)) {
      return NextResponse.json(
        failure("amount must be a positive number"),
        { status: 400 }
      );
    }

    const client = getUserClient();

    // ── Create transaction challenge ──────────────────────────────────────────
    // Circle returns a challengeId — the user must PIN-approve it client-side.
    // On Arc, USDC is the native gas token so no separate gas funding is needed.
    const txRes = await client.createTransaction({
      userToken: userToken!,
      walletId: walletId!,
      tokenId: tokenId!,
      destinationAddress: destinationAddress!,
      amounts: [amount!],
      idempotencyKey: idempotencyKey("usdc-send"),
      fee: {
        type: "level",
        config: { feeLevel: "MEDIUM" },
      },
    });

    const challengeId = txRes.data?.challengeId;
    if (!challengeId) {
      return NextResponse.json(
        failure("Circle did not return a challengeId"),
        { status: 502 }
      );
    }

    return NextResponse.json(
      success({
        challengeId,
        // Echo back for client-side display
        preview: {
          to: destinationAddress,
          amount: `${amount} USDC`,
          network: "Arc Mainnet",
          gasNote: "Gas paid in USDC (Arc native)",
        },
      })
    );
  } catch (e) {
    console.error("[POST /api/transaction]", e);
    return NextResponse.json(failure(normaliseError(e)), { status: 500 });
  }
}

// ── GET: Transaction history ──────────────────────────────────────────────────
export async function GET(req: NextRequest) {
  try {
    const userToken = req.headers.get("x-user-token");
    if (!userToken) {
      return NextResponse.json(failure("X-User-Token header is required"), { status: 401 });
    }

    const { searchParams } = req.nextUrl;
    const walletIds = searchParams.get("walletId");
    const pageSize = Number(searchParams.get("pageSize") ?? 20);
    const pageAfter = searchParams.get("pageAfter") ?? undefined;

    if (!walletIds) {
      return NextResponse.json(failure("walletId query param required"), { status: 400 });
    }

    const client = getUserClient();

    const historyRes = await client.listTransactions({
      userToken,
      walletIds: [walletIds],
      pageSize: Math.min(pageSize, 50), // cap at 50
      pageAfter,
    });

    const transactions = historyRes.data?.transactions ?? [];
    const nextPageAfter = historyRes.data?.pageAfter ?? null;

    return NextResponse.json(
      success({
        transactions: transactions.map(normaliseTx),
        nextPageAfter,
        count: transactions.length,
      })
    );
  } catch (e) {
    console.error("[GET /api/transaction]", e);
    return NextResponse.json(failure(normaliseError(e)), { status: 500 });
  }
}

// ─── Normalise transaction for frontend ───────────────────────────────────────
function normaliseTx(tx: Record<string, unknown>) {
  return {
    id: tx.id,
    state: tx.state,         // INITIATED | PENDING_RISK_SCREENING | SENT | CONFIRMED | FAILED | CANCELLED
    txHash: tx.txHash,
    amounts: tx.amounts,
    destinationAddress: tx.destinationAddress,
    sourceAddress: tx.sourceAddress,
    blockchain: tx.blockchain,
    createDate: tx.createDate,
    updateDate: tx.updateDate,
    networkFee: tx.networkFee,
  };
}

// ─── Validators ───────────────────────────────────────────────────────────────
function isValidAddress(addr: string): boolean {
  return /^0x[0-9a-fA-F]{40}$/.test(addr);
}

function isPositiveAmount(amount: string): boolean {
  const n = Number(amount);
  return !isNaN(n) && n > 0;
}
